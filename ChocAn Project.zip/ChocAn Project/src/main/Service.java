package main;

/**
 * This class creates an instance of a Service provided by ChocAn.
 * Each Service has a name, a code, and a fee.
 * @author David Hall
 */
public class Service {
	
	String name;
	int code;
	int fee = 0;
	
	/**
	 * Creates an instance of a Service.
	 * @param name The service name.
	 * @param code The service code.
	 * @param fee The service fee.
	 */
	public Service(String name, int code, int fee) {
		this.name = name;
		this.code = code;
		this.fee = fee;
	}
	
	/**
	 * Sets or changes the name of a service.
	 * @param x The new service name.
	 */
	public void setName(String x) {
		name = x;
	}
	
	/**
	 * Sets or changes the code of a service.
	 * @param x The new service code.
	 */
	public void setCode(int x) {
		code = x;
	}
	
	/**
	 * Sets or changes the fee of a service.
	 * @param x The new service fee.
	 */
	public void setFee(int x) {
		if(x < 0){
			throw new IllegalArgumentException();
		}
		fee = x;
	}
	
	/**
	 * Returns the service name.
	 * @return The service's name.
	 */
	public String getName() {
		return name;
	}
	
	/**
	 * Returns the service code.
	 * @return The service's code.
	 */
	public int getCode() {
		return code;
	}
	
	/**
	 * Returns the service fee.
	 * @return The service's fee.
	 */
	public int getFee() {
		return fee;
	}
}
