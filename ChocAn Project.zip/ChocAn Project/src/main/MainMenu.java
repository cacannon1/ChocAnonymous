package main;

import java.awt.*; 
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.UnsupportedEncodingException;

import javax.swing.*;    

/**
 * The first menu opened by the system. The main menu consists of 
 * buttons that link to the operator,manager, and provider menus.
 * @author Edward Liccardo
 */
public class MainMenu {
	
	/**
	 * Initializes the JFrame window to the variable f.
	 */
	JFrame f;
	static int provNum;
	
	/**
	 * The MainMenu constructor.
	 * Creates the main menu by calling functions that make the GUI.
	 */
	public MainMenu() {
		createGui();
		addButtons();
	}
	
	
	
	/**
	 * Creates the JFrame Main Menu GUI with a 3 by 1 layout and a window listener.
	 */
	public void createGui() {
		f = new JFrame("Main Menu");
		f.setSize(1500, 2000);
		f.setLayout(new GridLayout(3,1));
		f.addWindowListener(new WindowAdapter() {
	         public void windowClosing(WindowEvent windowEvent){
	        	 
	        	 try {
					Close.save();
					System.exit(0);
				} catch (FileNotFoundException | UnsupportedEncodingException e) {
					JOptionPane.showMessageDialog(null, "File not found!");
				}
				
	        	 System.exit(0);
	         }        
	      });  
	}
	
	/**
	 * Adds the provider, manager, and operator buttons to the JFrame GUI using JButtons.
	 * Adds listeners to the buttons that prompt for login when clicked.
	 */
	public void addButtons() {
		JButton a = new JButton("Provider Menu");
		JButton b = new JButton("Manager Menu");
		JButton c = new JButton("Operator Menu");
		a.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainMenuControl.login(provNum, f);
			}
		});
		b.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainMenuControl.openManagerMenu(f);
			}
		});
		c.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainMenuControl.openOperatorMenu(f);
			}
		});
		f.add(a);
		f.add(b);
		f.add(c);
		f.setVisible(true);
	}
}
