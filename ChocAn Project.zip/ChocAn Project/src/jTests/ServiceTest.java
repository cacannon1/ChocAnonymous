package jTests;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
 
import main.Service;

/**
 * Get Provider Directory JUnit test cases
 * Tests the Service class.
 * @author Kinsey Callans
 */
public class ServiceTest {
	/*
	 * Success: edit the service data (name, code, and fee) and then return the correctly edited information.
	 * Sanity: change the name of the service and then change it back and return the correct service name.
	 * Failure: try to set the service fee to an invalid integer (negative).
	 */

	
	Service s;
	
	@Before
	public void setUp() throws Exception {
		s = new Service("Dance Exercise Session", 492274, 30);
	}
	
	@Test
	public void testSuccess() {
		s.setName("P");
		assertEquals(s.getName(), "P");
	}
	
	
	@Test
	public void testSanity() {
		s.setName("P");
		s.setName("Dance Exercise Session");
		assertEquals(s.getName(), "Dance Exercise Session");
	}
	
	
	@Test (expected = IllegalArgumentException.class)
	public void testFailure() {
		s.setFee(-1);
	}
}