package jTests;

import java.io.IOException;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import main.User;
import main.EFTReport;
import main.Database;

public class EFTReportTest {
	
	/*
	 * Success: Creates John EFT Report.
	 * Sanity: Compares the provider name with the EFT report provider name.
	 * Failure: Creates a blank EFT Report titled "Does not exist".
	 */
	
	User John;
	
	@Before
	public void setUp() throws Exception {
		John = new User("John", "644 Street", "Tuscaloosa", "Alabama", "36532", 1, false);
		Database.providers.add(John);
	}

	@Test
	public void testSuccess() throws IOException {
		EFTReport.produceReport(1);
	}
	
	@Test
	public void testSanity(){
		assertEquals(John.getName(), EFTReport.getName(1));
	}
	
	@Test 
	public void testFailure() throws IOException{
		EFTReport.produceReport(-1);
	}

}
