package jTests;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

import main.User;

/**
 * Manage member JUnit test cases
 * Tests the User class.
 * @author Edward Liccardo
 */
public class ManageUserTest {
	/*
	 * Success: edit member data and then return the correctly edited information.
	 * Sanity: change a member's name and then change it back and return the correct name.
	 * Failure: try to set a user's status using a string.
	 */
	
	User paul;
	
	@Before
	public void setUp() throws Exception {
		paul = new User("Eddie","69 Gucci Blvd.", "Chicago", "Illinois", "60201", 1,true);
	}

	@Test
	public void testSuccess() {
		paul.setName("Paul");
		assertEquals(paul.getName(), "Paul");
	}
	
	
	@Test
	public void testSanity() {
		paul.setName("Paul");
		paul.setName("Eddie");
		assertEquals(paul.getName(), "Eddie");
	}
	
	
	
	@Test (expected = IllegalArgumentException.class)
	public void testFailure() {
		paul.setZip("-5000");
	}
	
}
