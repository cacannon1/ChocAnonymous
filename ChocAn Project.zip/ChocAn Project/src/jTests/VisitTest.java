package jTests;
import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
 
import main.Visit;

/**
 * Get Provider Directory JUnit test cases
 * Tests the Service class.
 * @author Caroline Cannon
 */

public class VisitTest {
	/*
	 * Success: edit the service data (name, code, and fee) and then return the correctly edited information.
	 * Sanity: change the name of the service and then change it back and return the correct service name.
	 * Failure: try to set the service fee to an invalid integer (negative).
	 */

	
	Visit c;
	
	@Before
	public void setUp() throws Exception {
		c = new Visit("02-22-1999", "10:30:00", 123123, 100000002, 100000011, "None");
	}
	
	@Test
	public void testSuccess() {
		c.setComments("Hello");
		assertEquals(c.getComments(), "Hello");
	}
	
	
	@Test
	public void testSanity() {
		c.setComments("Hello");
		c.setComments("How are you");
		assertEquals(c.getComments(), "How are you");
	}
	
	
	@Test (expected = IllegalArgumentException.class)
	public void testFailure() {
		c.setDate("-1");
	}
}